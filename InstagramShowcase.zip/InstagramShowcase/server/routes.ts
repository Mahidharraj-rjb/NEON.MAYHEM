import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.json({ success: true, contact });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(400).json({ 
        success: false, 
        message: "Invalid contact data provided" 
      });
    }
  });

  // Get all contacts (for admin purposes)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ 
        message: "Failed to fetch contacts" 
      });
    }
  });

  // Instagram feed proxy (placeholder for Instagram API integration)
  app.get("/api/instagram/feed", async (req, res) => {
    try {
      // In a real implementation, this would call Instagram Basic Display API
      // For now, return empty array to avoid mocking data
      const instagramToken = process.env.INSTAGRAM_ACCESS_TOKEN;
      
      if (!instagramToken) {
        return res.json({ 
          posts: [], 
          error: "Instagram API not configured. Please add INSTAGRAM_ACCESS_TOKEN to environment variables." 
        });
      }

      // Placeholder for actual Instagram API call
      // const response = await fetch(`https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,permalink,thumbnail_url&access_token=${instagramToken}`);
      
      res.json({ 
        posts: [], 
        message: "Instagram API integration ready - implement actual API calls here" 
      });
    } catch (error) {
      console.error("Instagram API error:", error);
      res.status(500).json({ 
        posts: [],
        error: "Failed to fetch Instagram posts" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
