import { Play } from "lucide-react";

export default function PortfolioSection() {
  const portfolioItems = [
    {
      id: 1,
      title: "Cyberpunk Anime Edit",
      description: "High-energy anime edit with neon transitions and electronic beats",
      image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["Anime", "Neon"]
    },
    {
      id: 2,
      title: "Meme Compilation",
      description: "Viral anime meme edits with perfect timing and effects",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["Memes", "Viral"]
    },
    {
      id: 3,
      title: "AMV Masterpiece",
      description: "Epic anime music video with cinematic editing and effects",
      image: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["AMV", "Cinematic"]
    },
    {
      id: 4,
      title: "Character Tribute",
      description: "Emotional character-focused edit with stunning visual storytelling",
      image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["Character", "Emotional"]
    },
    {
      id: 5,
      title: "Trending Edit",
      description: "Latest viral anime edit featuring popular characters and scenes",
      image: "https://images.unsplash.com/photo-1555421689-d68471e189f2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["Trending", "Popular"]
    },
    {
      id: 6,
      title: "Custom Commission",
      description: "Personalized anime edit created for client specifications",
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      tags: ["Custom", "Commission"]
    }
  ];

  return (
    <section id="portfolio" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">PORTFOLIO</span> <span className="neon-red text-glow">SHOWCASE</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A collection of my finest anime edits, featuring dynamic transitions, neon effects, and cyberpunk aesthetics.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item) => (
            <div key={item.id} className="group relative overflow-hidden rounded-xl bg-[hsl(var(--dark-gray))] neon-border hover-glow">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--deep-black))] via-transparent to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-xl font-bold neon-red mb-2">{item.title}</h3>
                <p className="text-gray-300 text-sm">{item.description}</p>
                <div className="flex items-center mt-3 space-x-2">
                  {item.tags.map((tag) => (
                    <span 
                      key={tag}
                      className={`px-2 py-1 rounded text-xs ${
                        tag === "Anime" || tag === "Character" || tag === "Trending" || tag === "Custom"
                          ? "bg-[hsl(var(--neon-red))]/20 text-[hsl(var(--neon-red))]"
                          : "bg-[hsl(var(--electric-blue))]/20 text-[hsl(var(--electric-blue))]"
                      }`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <button className="bg-[hsl(var(--neon-red))] hover-glow px-8 py-4 rounded-lg font-semibold text-white neon-border transition-all duration-300 flex items-center gap-2 mx-auto">
            <Play className="w-5 h-5" />
            Watch All Edits
          </button>
        </div>
      </div>
    </section>
  );
}
