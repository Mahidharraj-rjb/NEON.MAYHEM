import { Instagram, Mail } from "lucide-react";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-16">
      {/* Background image with overlay */}
      <div className="absolute inset-0 z-10">
        <img 
          src="https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Anime editing workspace" 
          className="w-full h-full object-cover opacity-20" 
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(var(--deep-black))]/70 via-transparent to-[hsl(var(--deep-black))]/90"></div>
      </div>
      
      <div className="relative z-20 text-center px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-7xl font-black mb-6">
          <span className="text-white">NEON</span>
          <span className="neon-red animate-neon-pulse">.</span>
          <span className="neon-red">MAYAHEM</span>
        </h1>
        
        <div className="text-xl md:text-2xl mb-8 h-8 overflow-hidden">
          <div className="animate-typewriter electric-blue font-mono">
            Anime Editor • Content Creator • Digital Artist
          </div>
        </div>
        
        <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto leading-relaxed">
          Transforming anime into stunning visual experiences with cutting-edge editing techniques and cyberpunk aesthetics.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button 
            onClick={() => scrollToSection("instagram")}
            className="bg-[hsl(var(--neon-red))] hover-glow px-8 py-4 rounded-lg font-semibold text-white neon-border transition-all duration-300 flex items-center gap-2"
          >
            <Instagram className="w-5 h-5" />
            View My Work
          </button>
          <button 
            onClick={() => scrollToSection("contact")}
            className="border-2 border-[hsl(var(--electric-blue))] text-[hsl(var(--electric-blue))] hover:bg-[hsl(var(--electric-blue))] hover:text-[hsl(var(--deep-black))] px-8 py-4 rounded-lg font-semibold transition-all duration-300 flex items-center gap-2"
          >
            <Mail className="w-5 h-5" />
            Hire Me
          </button>
        </div>
      </div>
      
      {/* Floating elements */}
      <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-[hsl(var(--neon-red))] rounded-full animate-float opacity-60"></div>
      <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-[hsl(var(--electric-blue))] rounded-full animate-float opacity-60" style={{animationDelay: "2s"}}></div>
      <div className="absolute bottom-1/4 left-1/3 w-2 h-2 bg-[hsl(var(--neon-red))] rounded-full animate-float opacity-60" style={{animationDelay: "4s"}}></div>
    </section>
  );
}
