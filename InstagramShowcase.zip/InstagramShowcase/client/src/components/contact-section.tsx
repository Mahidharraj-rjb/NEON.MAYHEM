import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Send, Clock, Instagram, Youtube, Twitter } from "lucide-react";
import { FaTiktok } from "react-icons/fa";

const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  serviceType: z.string().min(1, "Please select a service type"),
  projectDetails: z.string().min(10, "Please provide more details about your project"),
});

type ContactFormData = z.infer<typeof contactSchema>;

export default function ContactSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      serviceType: "",
      projectDetails: "",
    },
  });

  const mutation = useMutation({
    mutationFn: (data: ContactFormData) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "I'll get back to you within 24 hours.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: () => {
      toast({
        title: "Failed to send message",
        description: "Please try again or contact me directly on social media.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactFormData) => {
    mutation.mutate(data);
  };

  const socialLinks = [
    {
      platform: "Instagram",
      handle: "@Neon.Mayahem",
      url: "https://instagram.com/neon.mayahem",
      icon: Instagram,
      bgColor: "bg-gradient-to-r from-purple-500 to-pink-500"
    },
    {
      platform: "YouTube", 
      handle: "Neon Mayahem",
      url: "https://youtube.com/@neonmayahem",
      icon: Youtube,
      bgColor: "bg-red-600"
    },
    {
      platform: "TikTok",
      handle: "@neonmayahem", 
      url: "https://tiktok.com/@neonmayahem",
      icon: FaTiktok,
      bgColor: "bg-black"
    },
    {
      platform: "Twitter",
      handle: "@NeonMayahem",
      url: "https://twitter.com/neonmayahem",
      icon: Twitter,
      bgColor: "bg-blue-500"
    }
  ];

  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">GET IN</span> <span className="neon-red text-glow">TOUCH</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Ready to bring your anime vision to life? Let's create something amazing together.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div className="bg-[hsl(var(--dark-gray))] rounded-xl p-8 neon-border">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Your name"
                          className="bg-[hsl(var(--darker-gray))] border-gray-600 text-white placeholder-gray-400 focus:border-[hsl(var(--neon-red))] focus:ring-[hsl(var(--neon-red))]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Email</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="your@email.com"
                          className="bg-[hsl(var(--darker-gray))] border-gray-600 text-white placeholder-gray-400 focus:border-[hsl(var(--neon-red))] focus:ring-[hsl(var(--neon-red))]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="serviceType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Service Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-[hsl(var(--darker-gray))] border-gray-600 text-white focus:border-[hsl(var(--neon-red))] focus:ring-[hsl(var(--neon-red))]">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-[hsl(var(--darker-gray))] border-gray-600">
                          <SelectItem value="AMV Creation">AMV Creation</SelectItem>
                          <SelectItem value="Meme Edit">Meme Edit</SelectItem>
                          <SelectItem value="Character Tribute">Character Tribute</SelectItem>
                          <SelectItem value="Custom Project">Custom Project</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="projectDetails"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Project Details</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Tell me about your project..."
                          className="bg-[hsl(var(--darker-gray))] border-gray-600 text-white placeholder-gray-400 focus:border-[hsl(var(--neon-red))] focus:ring-[hsl(var(--neon-red))] min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  disabled={mutation.isPending}
                  className="w-full bg-[hsl(var(--neon-red))] hover-glow px-6 py-4 rounded-lg font-semibold text-white neon-border transition-all duration-300"
                >
                  <Send className="w-4 h-4 mr-2" />
                  {mutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </div>
          
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold neon-red mb-6">Let's Connect</h3>
              <p className="text-gray-300 text-lg leading-relaxed mb-6">
                I'm always excited to work on new projects and collaborate with fellow anime enthusiasts. Whether you need a custom AMV, viral meme edit, or something completely unique, I'm here to bring your vision to life.
              </p>
            </div>
            
            {/* Social Links */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-white mb-4">Follow the Journey</h4>
              <div className="flex flex-col space-y-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.platform}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-4 text-gray-300 hover:text-[hsl(var(--neon-red))] transition-colors duration-300"
                  >
                    <div className={`w-12 h-12 ${social.bgColor} rounded-lg flex items-center justify-center`}>
                      <social.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold">{social.platform}</div>
                      <div className="text-sm text-gray-400">{social.handle}</div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
            
            {/* Response Time */}
            <div className="bg-[hsl(var(--darker-gray))] rounded-lg p-6 neon-border">
              <div className="flex items-center space-x-3 mb-3">
                <Clock className="w-5 h-5 neon-red" />
                <h4 className="text-lg font-bold text-white">Response Time</h4>
              </div>
              <p className="text-gray-300">I typically respond to all inquiries within 24 hours. For urgent projects, feel free to reach out on social media for faster communication.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
