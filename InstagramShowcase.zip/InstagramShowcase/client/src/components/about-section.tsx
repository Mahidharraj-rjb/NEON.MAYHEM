import { Video, Palette, Music, Zap, Heart, Wand2 } from "lucide-react";

export default function AboutSection() {
  const skills = [
    { icon: Video, label: "Video Editing" },
    { icon: Wand2, label: "Visual Effects" },
    { icon: Music, label: "Audio Sync" },
    { icon: Palette, label: "Color Grading" },
    { icon: Zap, label: "Motion Graphics" },
    { icon: Heart, label: "Anime Culture" }
  ];

  const stats = [
    { value: "4", label: "Followers" },
    { value: "50+", label: "Edits Created" }
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-white">ABOUT</span> <span className="neon-red text-glow">NEON.MAYAHEM</span>
            </h2>
            <p className="text-xl text-gray-300 mb-6 leading-relaxed">
              I'm a passionate anime editor and digital content creator specializing in cyberpunk aesthetics and high-energy visual storytelling. I focus on transforming anime scenes into engaging visual experiences.
            </p>
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              My expertise spans from AMVs and character tributes to viral meme compilations and custom commissions. I use modern editing techniques combined with neon effects, smooth transitions, and perfectly synced audio to create content that resonates with the anime community.
            </p>
            
            {/* Skills */}
            <div className="mb-8">
              <h3 className="text-2xl font-bold neon-red mb-4">Skills & Expertise</h3>
              <div className="grid grid-cols-2 gap-4">
                {skills.map((skill) => (
                  <div key={skill.label} className="flex items-center space-x-3">
                    <skill.icon className="w-5 h-5 neon-red" />
                    <span>{skill.label}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl font-bold neon-red mb-2">{stat.value}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Anime editing workspace with multiple monitors" 
              className="rounded-2xl shadow-2xl neon-border animate-neon-pulse" 
            />
            
            {/* Floating skill badges */}
            <div className="absolute -top-4 -right-4 bg-[hsl(var(--neon-red))] rounded-full p-4 animate-float">
              <Video className="w-6 h-6 text-white" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-[hsl(var(--electric-blue))] rounded-full p-4 animate-float" style={{animationDelay: "2s"}}>
              <Wand2 className="w-6 h-6 text-[hsl(var(--deep-black))]" />
            </div>
            <div className="absolute top-1/2 -right-8 bg-[hsl(var(--neon-red))] rounded-full p-3 animate-float" style={{animationDelay: "4s"}}>
              <Heart className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
