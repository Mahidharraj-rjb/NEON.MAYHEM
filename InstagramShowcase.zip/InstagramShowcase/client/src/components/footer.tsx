import { Instagram, Youtube, Twitter, Heart } from "lucide-react";
import { FaTiktok } from "react-icons/fa";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-[hsl(var(--dark-gray))] border-t border-[hsl(var(--neon-red))]/30 py-12 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-bold neon-red mb-4">Neon.Mayahem</h3>
            <p className="text-gray-400 mb-4">
              Creating stunning anime edits with cyberpunk aesthetics and cutting-edge visual effects.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://instagram.com/neon.mayahem" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[hsl(var(--neon-red))] transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="https://youtube.com/@neonmayahem" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[hsl(var(--neon-red))] transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a 
                href="https://tiktok.com/@neonmayahem" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[hsl(var(--neon-red))] transition-colors"
              >
                <FaTiktok className="w-5 h-5" />
              </a>
              <a 
                href="https://twitter.com/neonmayahem" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[hsl(var(--neon-red))] transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold text-white mb-4">Services</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">AMV Creation</button></li>
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Meme Edits</button></li>
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Character Tributes</button></li>
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Custom Projects</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => scrollToSection("portfolio")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Portfolio</button></li>
              <li><button onClick={() => scrollToSection("about")} className="hover:text-[hsl(var(--neon-red))] transition-colors">About</button></li>
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Contact</button></li>
              <li><button onClick={() => scrollToSection("contact")} className="hover:text-[hsl(var(--neon-red))] transition-colors">Pricing</button></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Neon.Mayahem. All rights reserved. | Crafted with <Heart className="inline w-4 h-4 neon-red mx-1" /> for the anime community.
          </p>
        </div>
      </div>
    </footer>
  );
}
