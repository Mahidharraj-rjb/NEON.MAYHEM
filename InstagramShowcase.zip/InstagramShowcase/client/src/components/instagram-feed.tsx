import { useQuery } from "@tanstack/react-query";
import { Instagram } from "lucide-react";

interface InstagramPost {
  id: string;
  caption: string;
  media_type: string;
  media_url: string;
  permalink: string;
  thumbnail_url?: string;
}

interface InstagramResponse {
  posts: InstagramPost[];
  error?: string;
  message?: string;
}

export default function InstagramFeed() {
  const { data, isLoading, error } = useQuery<InstagramResponse>({
    queryKey: ["/api/instagram/feed"],
  });

  // Mock posts for UI demonstration when API is not configured
  const mockPosts = [
    {
      id: "1",
      caption: "New Edit Drop!",
      image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "2", 
      caption: "Behind the Scenes",
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "3",
      caption: "WIP Preview", 
      image: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "4",
      caption: "Tutorial Tips",
      image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "5",
      caption: "Community Love",
      image: "https://images.unsplash.com/photo-1555421689-d68471e189f2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "6",
      caption: "Collaboration",
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "7",
      caption: "Setup Tour",
      image: "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    },
    {
      id: "8",
      caption: "Process Reveal",
      image: "https://images.unsplash.com/photo-1551650992-6b43ce4b3672?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400"
    }
  ];

  return (
    <section id="instagram" className="py-20 px-4 sm:px-6 lg:px-8 bg-[hsl(var(--dark-gray))]/30 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">LATEST FROM</span> <span className="neon-red text-glow">INSTAGRAM</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Follow my journey and see my latest anime edits, behind-the-scenes content, and community interactions.
          </p>
          <a 
            href="https://instagram.com/neon.mayahem" 
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover-glow gap-2"
          >
            <Instagram className="w-5 h-5" />
            Follow @Neon.Mayahem
          </a>
        </div>
        
        {isLoading && (
          <div className="text-center text-gray-400">Loading Instagram feed...</div>
        )}

        {error && (
          <div className="text-center text-red-400 mb-8">
            Failed to load Instagram feed. Showing preview posts below.
          </div>
        )}

        {data?.error && (
          <div className="text-center text-yellow-400 mb-8">
            {data.error}
          </div>
        )}

        {data?.message && !data?.error && (
          <div className="text-center text-blue-400 mb-8">
            {data.message}
          </div>
        )}
        
        {/* Instagram Grid - Show mock posts when no real data available */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {(data?.posts?.length ? data.posts : mockPosts).map((post, index) => (
            <div key={post.id || index} className="group relative aspect-square overflow-hidden rounded-lg hover-glow">
              <img 
                src={post.media_url || post.image} 
                alt={post.caption || `Instagram post ${index + 1}`}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center">
                  <Instagram className="w-8 h-8 text-white mb-2 mx-auto" />
                  <p className="text-white text-sm">{post.caption || "Instagram Post"}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
