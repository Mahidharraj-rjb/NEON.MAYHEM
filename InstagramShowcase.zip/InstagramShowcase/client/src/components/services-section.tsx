import { Music, Laugh, User, Check } from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      id: 1,
      title: "AMV Creation",
      description: "Epic anime music videos with professional editing and effects",
      icon: Music,
      price: "$150+",
      iconBg: "bg-[hsl(var(--neon-red))]",
      buttonBg: "bg-[hsl(var(--neon-red))]",
      features: [
        "Custom song selection",
        "Advanced transitions", 
        "Color grading",
        "Multiple revisions"
      ]
    },
    {
      id: 2,
      title: "Meme Edits",
      description: "Viral anime meme compilations and trending content",
      icon: Laugh,
      price: "$75+",
      iconBg: "bg-[hsl(var(--electric-blue))]",
      buttonBg: "bg-[hsl(var(--electric-blue))] text-[hsl(var(--deep-black))] hover:bg-[hsl(var(--electric-blue))]/80",
      features: [
        "Trending formats",
        "Perfect timing",
        "Sound effects", 
        "Quick turnaround"
      ]
    },
    {
      id: 3,
      title: "Character Tributes",
      description: "Emotional character-focused edits with stunning visuals",
      icon: User,
      price: "$200+",
      iconBg: "bg-[hsl(var(--neon-red))]",
      buttonBg: "bg-[hsl(var(--neon-red))]",
      features: [
        "Character analysis",
        "Emotional storytelling",
        "Custom effects",
        "HD quality"
      ]
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[hsl(var(--dark-gray))]/30 relative z-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-white">EDITING</span> <span className="neon-red text-glow">SERVICES</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Professional anime editing services tailored to your vision and needs.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="bg-[hsl(var(--darker-gray))] rounded-xl p-8 neon-border hover-glow">
              <div className="text-center mb-6">
                <div className={`w-16 h-16 ${service.iconBg} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <service.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold neon-red mb-2">{service.title}</h3>
                <p className="text-gray-300">{service.description}</p>
              </div>
              
              <ul className="text-gray-400 space-y-2 mb-6">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="w-4 h-4 neon-red mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-4">{service.price}</div>
                <button className={`w-full ${service.buttonBg} hover-glow px-6 py-3 rounded-lg font-semibold text-white transition-all duration-300`}>
                  Get Started
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
